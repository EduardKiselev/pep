from django.db import models
from django.contrib.auth import get_user_model


User = get_user_model()


class Food(models.Model):
    description = models.CharField(max_length=150)
    ndbNumber = models.IntegerField()
    fdcId = models.IntegerField()
#    foodCategory = models.CharField(max_length=50)

    is_published = models.BooleanField(
        default=True,
        verbose_name='Опубликовано',
        help_text='Снимите галочку, чтобы не выводить продукт.')

    def __str__(self):
        return 'CLASS ' + self.description


class NutrientsName(models.Model):
    name = models.CharField(max_length=50)
    unit_name = models.CharField(max_length=10)
    is_published = models.BooleanField(
        default=True, verbose_name='Опубликовано',
        help_text='Снимите галочку, чтобы не выводить нутриент.')
    order = models.IntegerField(default=100)

    def __str__(self):
        return 'CLASS ' + self.name


class NutrientsQuantity(models.Model):
    food = models.ForeignKey(
        Food,
        verbose_name="Продукт",
        on_delete=models.CASCADE,
        related_name='quan')
    nutrient = models.ForeignKey(
        NutrientsName,
        verbose_name='Имя нутриента',
        on_delete=models.CASCADE,
        related_name='quan')
    amount = models.FloatField(verbose_name='Количество')

    def __str__(self):
        return '&CLASS ' + str(self.food) +\
            ': ' + str(self.nutrient) + '=' + str(self.amount) + '&'


class AnimalType(models.Model):
    title = models.CharField(blank=True, max_length=50)
    description = models.TextField(blank=True, verbose_name='Описание')

    def __str__(self):
        return self.title


class Animal(models.Model):
    name = models.CharField(verbose_name='Имя питомца', max_length=50)
    owner = models.ForeignKey(User, on_delete=models.CASCADE,
                               verbose_name='Хозяин')
    type = models.ForeignKey(AnimalType, on_delete=models.CASCADE, related_name='type', verbose_name='пол/фертильность')
    mass = models.FloatField(verbose_name='Вес', help_text='Масса питомца, целое число в кг')
    age = models.IntegerField(verbose_name='Возраст', help_text='Полное число лет')

    def __str__(self):
        return self.name
